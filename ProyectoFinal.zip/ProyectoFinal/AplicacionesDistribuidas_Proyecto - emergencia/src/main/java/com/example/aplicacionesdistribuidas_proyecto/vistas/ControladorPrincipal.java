package com.example.aplicacionesdistribuidas_proyecto.vistas;


import com.example.aplicacionesdistribuidas_proyecto.dao.PaquetesSuscripcionDao;
import com.example.aplicacionesdistribuidas_proyecto.dao.UsuarioDao;
import com.example.aplicacionesdistribuidas_proyecto.modelos.PaquetesSuscripcion;
import com.example.aplicacionesdistribuidas_proyecto.modelos.Usuario;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.Optional;

@Controller
@RequestMapping("/emergencia")
public class ControladorPrincipal {

    private static final String SOURCE_DIRECTORY = "G:\\Entrega\\AplicacionesDistribuidas_Proyecto - emergencia\\origen";
    private static final String TARGET_DIRECTORY = "G:\\Entrega\\AplicacionesDistribuidas_Proyecto - emergencia\\destino";

    @Autowired
    private UsuarioDao usuarioDao;

    @Autowired
    private PaquetesSuscripcionDao paquetesSuscripcionDao;

    @PostMapping("/guardarusuario")
    public ResponseEntity<String> guardarUsuario(@RequestBody Usuario usuario){
        /*if(usuarioDao.findByEmail(usuario.getemail()).isPresent() && usuarioDao.findByUserName(usuario.getuserName()).isPresent()){
            throw new IllegalArgumentException("Ya existe un usuario con el mismo nombre y email");
        }*/
        usuarioDao.save(usuario);
        return new ResponseEntity<>("Usuario creado exitosamente", HttpStatus.CREATED);
    }


    @GetMapping("/estadisticas/{id}/{password}")
    public ResponseEntity<Usuario> estadisticas(@PathVariable("id") Long id, @PathVariable("password") String password){
        if(!usuarioDao.findById(id).isPresent() && !usuarioDao.findByContrasenia(password).isPresent()){
            throw new IllegalArgumentException("No existe el usuario con el id  o contrasenia incorrecta" + id);
        }
        Optional<Usuario> u1 = usuarioDao.findById(id);
        Usuario usuario = new Usuario();
        usuario.setId(u1.get().getId());
        usuario.setNombre(u1.get().getNombre());
        usuario.setemail(u1.get().getemail());
        usuario.setContrasenia(u1.get().getContrasenia());
        usuario.setuserName(u1.get().getContrasenia());
        usuario.setSaldo(u1.get().getSaldo());
        return ResponseEntity.status(HttpStatus.OK).body(usuario);
        //return usuario;
    }

    @GetMapping("/downloadAndSave/{filename}/{id}/{contrasenia}")
    public ResponseEntity<String> downloadAndSaveFile(@PathVariable("filename") String filename,@PathVariable("id")Long id,@PathVariable("contrasenia") String password) {
        Optional<Usuario> u1 = usuarioDao.findById(id);

        if(u1.get().getSaldo()<=0){
            return ResponseEntity.status(HttpStatus.OK).body("Saldo insuficiente");
        }

        if (!usuarioDao.findByContrasenia(password).isPresent()){
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Contrasenia incorrecta");
        }

        File sourceFile = new File(SOURCE_DIRECTORY, filename);
        if (!sourceFile.exists()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("File not found: " + filename);
        }
        File targetFile = new File(TARGET_DIRECTORY, filename);
        try {
            Integer nuevoSaldo = u1.get().getSaldo()-1000;
            u1.get().setId(u1.get().getId());
            u1.get().setemail(u1.get().getemail());
            u1.get().setNombre(u1.get().getNombre());
            u1.get().setContrasenia(u1.get().getContrasenia());
            u1.get().setuserName(u1.get().getuserName());
            u1.get().setSaldo(nuevoSaldo);
            Files.copy(sourceFile.toPath(), targetFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
            sourceFile.getName();
            sourceFile.getTotalSpace();
            Usuario save = usuarioDao.save(u1.get());
            return ResponseEntity.ok("Archivo cargado exitosamente : " + filename + " saldo actualizado " + save.getSaldo() );
        } catch (IOException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error downloading and saving file: " + e.getMessage());
        }
    }

    @GetMapping("/suscription/{id}")
    public ResponseEntity<PaquetesSuscripcion> obtenerTipoSuscripcion(@PathVariable("id") Long id){
        Optional<PaquetesSuscripcion> o = paquetesSuscripcionDao.findById(id);
        PaquetesSuscripcion paquetesSuscripcion = new PaquetesSuscripcion();
        paquetesSuscripcion.setTipo(o.get().toString());
        paquetesSuscripcion.setId(o.get().getId());
        paquetesSuscripcion.setPrecio(o.get().getPrecio());
        paquetesSuscripcion.setDiasServicio(o.get().getDiasServicio());
        return ResponseEntity.status(HttpStatus.OK).body(paquetesSuscripcion);
    }


    @PostMapping("/suscription")
    public ResponseEntity<String> guardarSuscription(@RequestBody PaquetesSuscripcion suscripcion){
        /*if(usuarioDao.findByEmail(usuario.getemail()).isPresent() && usuarioDao.findByUserName(usuario.getuserName()).isPresent()){
            throw new IllegalArgumentException("Ya existe un usuario con el mismo nombre y email");
        }*/
        paquetesSuscripcionDao.save(suscripcion);
        return new ResponseEntity<>("Suscripcion creada exitosamente", HttpStatus.CREATED);
    }
}
