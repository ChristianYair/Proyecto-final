package com.example.aplicacionesdistribuidas_proyecto.dao;

import com.example.aplicacionesdistribuidas_proyecto.modelos.Usuario;
import org.springframework.data.repository.CrudRepository;

import java.util.Locale;
import java.util.Optional;

public interface UsuarioDao extends CrudRepository<Usuario, Long> {

    Optional<Usuario> findByUserName(String username);
    Optional<Usuario> findByEmail(String email);
    Optional<Usuario> findByContrasenia(String contrasenia);
}
