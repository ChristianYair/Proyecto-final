package com.example.aplicacionesdistribuidas_proyecto.dao;

import com.example.aplicacionesdistribuidas_proyecto.modelos.PaquetesSuscripcion;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PaquetesSuscripcionDao extends JpaRepository<PaquetesSuscripcion,Long> {
}
