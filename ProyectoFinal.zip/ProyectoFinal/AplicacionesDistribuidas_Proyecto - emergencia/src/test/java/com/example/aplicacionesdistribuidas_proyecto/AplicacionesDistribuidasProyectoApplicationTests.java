package com.example.aplicacionesdistribuidas_proyecto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AplicacionesDistribuidasProyectoApplicationTests {

	@Test
	void contextLoads() {
	}

}
