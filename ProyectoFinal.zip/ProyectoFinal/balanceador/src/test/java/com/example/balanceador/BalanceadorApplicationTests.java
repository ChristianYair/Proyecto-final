package com.example.balanceador;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BalanceadorApplicationTests {

    @Test
    void contextLoads() {
    }

}
