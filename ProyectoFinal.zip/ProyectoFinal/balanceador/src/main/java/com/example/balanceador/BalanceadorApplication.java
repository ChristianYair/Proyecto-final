package com.example.balanceador;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class BalanceadorApplication {

    public static void main(String[] args) {
        SpringApplication.run(BalanceadorApplication.class, args);
    }

    @Bean
    public RouteLocator customRouteLocator(RouteLocatorBuilder builder) {
        return builder.routes()
                .route("servicio1", r -> r.path("/main/**")
                        .uri("http://localhost:9090"))
                .route("servicio2", r -> r.path("/emergencia/**")
                        .uri("http://localhost:9091"))
                .build();
    }

}
